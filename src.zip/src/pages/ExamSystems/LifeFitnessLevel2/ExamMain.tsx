// ✅ 퀴즈 시험 화면 리팩토링 디자인 적용

import React, { useState, useEffect } from "react";

const QuizExamPage = () => {
  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [timeLeft, setTimeLeft] = useState(6000);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isTimerWarning, setIsTimerWarning] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const examSubject = "스포츠사회학";
  const totalQuestions = 20;

  const questions = [
    {
      id: 1,
      question: "스포츠 사회학에서 '사회화'의 개념으로 가장 적절한 것은?",
      options: [
        "개인이 사회의 규범과 가치를 내면화하는 과정",
        "개인이 사회적 지위를 획득하는 과정",
        "개인이 사회적 관계를 형성하는 과정",
        "개인이 사회적 변화에 적응하는 과정",
      ],
    },
    {
      id: 2,
      question: "스포츠 참여의 사회적 요인으로 가장 적절하지 않은 것은?",
      image: "https://readdy.ai/api/search-image?query=sports-social&width=350&height=200",
      options: ["가족의 영향", "개인의 신체적 능력", "사회경제적 지위", "또래 집단의 압력"],
    },
    {
      id: 3,
      question: "현대 스포츠에서 미디어의 역할에 대한 설명으로 옳지 않은 것은?",
      image: "https://readdy.ai/api/search-image?query=sports-media&width=350&height=200",
      options: [
        "스포츠 경기의 대중적 접근성을 높인다",
        "스포츠 스타의 이미지 형성에 영향을 미친다",
        "스포츠의 상업화를 감소시킨다",
        "스포츠 문화의 확산에 기여한다",
      ],
    },
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev === 300) setIsTimerWarning(true);
        return prev > 0 ? prev - 1 : 0;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  const selectAnswer = (questionId: number, optionIndex: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
  };

  const goToPreviousQuestion = () => {
    if (currentQuestion > 1) setCurrentQuestion((prev) => prev - 1);
  };

  const goToNextQuestion = () => {
    if (currentQuestion < totalQuestions) setCurrentQuestion((prev) => prev + 1);
  };

  const saveTemporary = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const currentQuestionData = questions.find((q) => q.id === currentQuestion) || questions[0];

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 text-gray-900 font-sans">
      <nav className="fixed w-full top-0 bg-white shadow-md z-10">
        <div className="flex justify-between items-center px-4 py-3">
          <div className="text-gray-700 cursor-pointer">
            <i className="fas fa-arrow-left mr-2"></i>
          </div>
          <div className="text-lg font-bold">{examSubject}</div>
          <div className={`text-base font-medium ${isTimerWarning ? "text-red-600" : "text-gray-700"}`}>
            {formatTime(timeLeft)}
          </div>
        </div>
        <div className="w-full px-4 py-2 bg-gray-100 flex justify-between items-center">
          <div className="text-sm font-medium">문제 {currentQuestion} / {totalQuestions}</div>
          <div className="text-sm text-gray-600">
            {selectedAnswers[currentQuestion] !== undefined ? "답변 완료" : "미답변"}
          </div>
        </div>
      </nav>

      <main className="flex-grow pt-24 pb-20 px-4">
        <div className="bg-white rounded-lg shadow-sm p-5 mb-4">
          <div className="mb-4">
            <span className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm font-medium">
              문제 {currentQuestion}
            </span>
          </div>
          <div className="space-y-4">
            <p className="text-base leading-relaxed">{currentQuestionData.question}</p>
            {currentQuestionData.image && (
              <div className="rounded-lg overflow-hidden bg-gray-50">
                <img
                  src={currentQuestionData.image}
                  alt={`문제 ${currentQuestion} 이미지`}
                  className="w-full h-auto object-contain max-h-[200px]"
                />
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <h3 className="text-sm font-medium text-gray-600 mb-3">답안을 선택하세요</h3>
          <div className="space-y-3">
            {currentQuestionData.options.map((option, index) => (
              <div
                key={index}
                className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                  selectedAnswers[currentQuestion] === index
                    ? "bg-blue-50 border-blue-300"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
                onClick={() => selectAnswer(currentQuestion, index)}
              >
                <div
                  className={`w-7 h-7 flex items-center justify-center rounded-full mr-3 ${
                    selectedAnswers[currentQuestion] === index
                      ? "bg-blue-600 text-white"
                      : "bg-gray-100 text-gray-600"
                  }`}
                >
                  {index + 1}
                </div>
                <span className="text-sm">{option}</span>
              </div>
            ))}
          </div>

          <div className="mt-6 grid grid-cols-3 gap-3">
            <button
              onClick={goToPreviousQuestion}
              disabled={currentQuestion === 1}
              className={`flex items-center justify-center py-3 px-4 bg-white hover:bg-gray-50 rounded-xl shadow-sm transition-all duration-200 !rounded-button group ${
                currentQuestion === 1 ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              <i className="fas fa-chevron-left text-gray-400 group-hover:text-gray-600 mr-2 transition-colors"></i>
              <span className="text-sm font-medium text-gray-600 group-hover:text-gray-800">이전</span>
            </button>

            <button
              onClick={goToNextQuestion}
              disabled={currentQuestion === totalQuestions}
              className={`flex items-center justify-center py-3 px-4 bg-white hover:bg-gray-50 rounded-xl shadow-sm transition-all duration-200 !rounded-button group ${
                currentQuestion === totalQuestions ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              <span className="text-sm font-medium text-gray-600 group-hover:text-gray-800 mr-2">다음</span>
              <i className="fas fa-chevron-right text-gray-400 group-hover:text-gray-600 transition-colors"></i>
            </button>

            <button
              onClick={() => setShowConfirmModal(true)}
              disabled={Object.keys(selectedAnswers).length < totalQuestions}
              className={`flex items-center justify-center py-3 px-4 rounded-xl shadow-sm transition-all duration-200 !rounded-button ${
                Object.keys(selectedAnswers).length < totalQuestions
                  ? "bg-gray-100 cursor-not-allowed"
                  : "bg-blue-500 hover:bg-blue-600"
              }`}
            >
              <i className={`fas fa-paper-plane mr-2 ${
                Object.keys(selectedAnswers).length < totalQuestions ? "text-gray-400" : "text-white"
              }`}></i>
              <span className={`text-sm font-medium ${
                Object.keys(selectedAnswers).length < totalQuestions ? "text-gray-500" : "text-white"
              }`}>
                {Object.keys(selectedAnswers).length < totalQuestions
                  ? `${Object.keys(selectedAnswers).length}/${totalQuestions}`
                  : "제출하기"}
              </span>
            </button>
          </div>
        </div>

        <div className="mt-4">
          <button
            onClick={saveTemporary}
            className="w-full flex items-center justify-center py-3 px-4 bg-white hover:bg-gray-50 border border-gray-200 rounded-xl shadow-sm transition-all duration-200 !rounded-button group"
          >
            <i className="fas fa-save text-gray-400 group-hover:text-gray-600 mr-2 transition-colors"></i>
            <span className="text-sm font-medium text-gray-600 group-hover:text-gray-800">임시저장</span>
          </button>
        </div>

        {isSaved && (
          <div className="fixed top-20 left-0 right-0 mx-auto w-3/4 bg-green-100 text-green-800 px-4 py-2 rounded-lg shadow-md text-center text-sm">
            답안이 임시 저장되었습니다.
          </div>
        )}

        {showConfirmModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 px-4">
            <div className="bg-white rounded-lg p-5 w-full max-w-sm">
              <h3 className="text-lg font-bold mb-3">답안 제출 확인</h3>
              <p className="text-sm text-gray-600 mb-4">
                모든 답안을 제출하시겠습니까? 제출 후에는 수정이 불가능합니다.
              </p>
              <div className="flex justify-between items-center mt-4">
                <button
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 !rounded-button cursor-pointer"
                  onClick={() => setShowConfirmModal(false)}
                >
                  취소
                </button>
                <button
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg !rounded-button cursor-pointer"
                  onClick={() => {
                    window.location.href = "/quiz-result";
                  }}
                >
                  제출하기
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default QuizExamPage;
